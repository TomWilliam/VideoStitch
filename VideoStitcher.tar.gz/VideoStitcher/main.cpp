#include "opencv2/opencv.hpp"
#include "opencv2/stitching.hpp"
#include "opencv2/nonfree/features2d.hpp"

using namespace cv;

int main(int, char**)
{
    //VideoCapture cap("MVI_0542.MOV");
    //VideoCapture cap0("MVI_0542.MOV");
    VideoCapture cap0("0.MP4");
    VideoCapture cap1("1.MP4");
    VideoCapture cap2("2.MP4");
    VideoCapture cap3("3.MP4");

    bool try_use_gpu = true;    // use GPU
    cv::Stitcher stitcher = cv::Stitcher::createDefault(try_use_gpu);
    stitcher.setWarper(new cv::CylindricalWarperGpu());
    stitcher.setWaveCorrection(false);
    stitcher.setSeamEstimationResol(0.001);
    stitcher.setPanoConfidenceThresh(0.1);

    //stitcher.setSeamFinder(new cv::detail::GraphCutSeamFinder(cv::detail::GraphCutSeamFinderBase::COST_COLOR_GRAD));
    stitcher.setSeamFinder(new cv::detail::NoSeamFinder());
    stitcher.setBlender(cv::detail::Blender::createDefault(cv::detail::Blender::NO, true));
    //stitcher.setExposureCompensator(cv::detail::ExposureCompensator::createDefault(cv::detail::ExposureCompensator::NO));
    stitcher.setExposureCompensator(new cv::detail::NoExposureCompensator());

    std::vector<cv::Mat> images(1);
    if(!cap0.isOpened() || !cap1.isOpened() || !cap2.isOpened() || !cap3.isOpened())  // check if we succeeded
        return -1;

    cap0 >> images[0];
    cap1 >> images[1];
    cap2 >> images[2];
    cap3 >> images[3];

    cap0 >> images[0];
    cap1 >> images[1];
    cap2 >> images[2];
    cap3 >> images[3];

    cap0 >> images[0];
    cap1 >> images[1];
    cap2 >> images[2];
    cap3 >> images[3];

    Mat pano_result;
    cv::Stitcher::Status status = stitcher.estimateTransform(images);

    //Mat edges;
    namedWindow("edges",1);
    for(;;)
    {
        cap0 >> images[0];
        cap1 >> images[1];
        cap2 >> images[2];
        cap3 >> images[3];
        cv::Stitcher::Status status = stitcher.composePanorama(images, pano_result);
        imshow("pano", pano_result);
        waitKey(3);
    }
    return 0;
}
